/* This file was automatically generated. Do not edit or copy.
 */

#pragma once

#define QMK_VERSION "c9262c-dirty"
#define QMK_BUILDDATE "2021-09-04-09:50:13"
#define CHIBIOS_VERSION "2021-09-04-09:50:13"
#define CHIBIOS_CONTRIB_VERSION "2021-09-04-09:50:13"
