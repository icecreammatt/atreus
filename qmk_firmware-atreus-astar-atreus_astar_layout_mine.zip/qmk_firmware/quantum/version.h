/* This file was automatically generated. Do not edit or copy.
 */

#pragma once

#define QMK_VERSION "a01057-dirty"
#define QMK_BUILDDATE "2021-09-03-14:26:43"
#define CHIBIOS_VERSION "2021-09-03-14:26:43"
#define CHIBIOS_CONTRIB_VERSION "2021-09-03-14:26:43"
