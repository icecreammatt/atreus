# Jotix ortho 4x4 keymap

Tested on jotpad16